var int = document.getElementById("int");
int.addEventListener("mouseover", function() {
  int.style.color = "#FF0000";
}, false);
int.addEventListener("mouseout", function() {
  int.style.color = "#000000";
}, false);
