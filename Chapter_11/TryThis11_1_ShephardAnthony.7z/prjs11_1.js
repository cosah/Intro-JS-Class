var mywin_width = 0;
mywin_width = window.innerWidth;

if (mywin_width >= 1000){
  window.location = "http://www.scripttheweb.com/js/";
}
else{
  window.location = "http://www.scripttheweb.com/css/";
}
