var my_win = window.innerWidth;
if (my_win >= 1000) {
  window.location = "http://en.wikipedia.org/wiki/Kiwifruit#Fuzzy_kiwifruit";
}
else{alert("can't do it");
}
